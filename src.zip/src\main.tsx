import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom' // NEW IMPORT
import App from './App'
import './index.css' 
import './i18n/config';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter> {/* WRAP THE APP HERE */}
      <App />
    </BrowserRouter>
  </React.StrictMode>,
)